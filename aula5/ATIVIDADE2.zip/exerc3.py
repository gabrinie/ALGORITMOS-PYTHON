#exercicio 3 
#Dados três inteiros, qual a soma deles?


n1 = int(input("Digite um número"))
n2 = int(input("Digite outro número"))
n3 = int(input("Digite mais um número"))
soma = n1 + n2 + n3
print("A soma de {} + {} + {} é {}".format(n1, n2, n3, soma))

