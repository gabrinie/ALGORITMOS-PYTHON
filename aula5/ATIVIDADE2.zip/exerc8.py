#Exercicio 8
#A família Silva vai passar as férias na Europa e quer saber quantos euros vale o dinheiro em real que ela levará. Dados um valor na moeda real e a cotação do euro, qual o valor correspondente em euros?

real = float(input("Informe o valor em real"))
euro = real / 5.38
print("Você tem {:.2f} euros".format(euro))
