#Exercicio 7
#Dado um inteiro, qual o seu antecessor e o seu sucessor?

num = int(input("Digite um número"))
ant = num - 1 
suc = num + 1 
print("O antecessor de {} é {} e o sucessor {}".format(num, ant, suc))
