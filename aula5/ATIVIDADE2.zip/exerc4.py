#Exercicio 4
# Dadas a base e a altura de um retângulo, qual sua área? A=base⋅altura

base = float(input("Digite a base"))
altura = float(input("Digite a altura"))
a = base * altura
print("A area do retângulo é de {}".format(a))
