#Exercicio 5 
#Dado o raio de um círculo, qual sua área? A=πr 

raio = float(input("Digite o raio do círculo"))
a = raio * 3.14
print("A área é {:.2f}".format(a))

